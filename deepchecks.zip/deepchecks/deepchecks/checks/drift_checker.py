"""
drift_checker.py

Custom utility class for detailed data drift comparison between two datasets.
"""

import pandas as pd
import numpy as np

class DriftChecker:
    """
    DriftChecker compares two pandas DataFrames for structural and statistical drift.

    Parameters:
    -----------
    null_drift : bool
        Whether to compute null percentage drift.
    dup_drift : bool
        Whether to compute duplicate percentage drift.
    mean_drift : bool
        Whether to compute mean difference for numeric columns.
    category_drift : bool
        Whether to detect category set differences.
    type_drift : bool
        Whether to detect dtype changes.
    verbose : bool
        Whether to print the report in the console.

    Usage:
    -------
    checker = DriftChecker()
    report = checker.check(df1, df2)
    """

    def __init__(self, null_drift=True, dup_drift=True, mean_drift=True, category_drift=True, type_drift=True, verbose=True):
        # Initialize feature flags
        self.null_drift = null_drift
        self.dup_drift = dup_drift
        self.mean_drift = mean_drift
        self.category_drift = category_drift
        self.type_drift = type_drift
        self.verbose = verbose

    def check(self, df1: pd.DataFrame, df2: pd.DataFrame) -> pd.DataFrame:
        
        # Identify columns common to both DataFrames
        common_cols = df1.columns.intersection(df2.columns)
        
        # Raise error if no common columns found
        if len(common_cols) == 0:
            raise ValueError("No common columns between the two DataFrames.")

        # Filter both DataFrames to include only common columns
        df1 = df1[common_cols]
        df2 = df2[common_cols]

        report = []

        # Iterate through each common column to compute drift metrics
        for col in common_cols:
            row = {"Column Name": col, "DataType": str(df1[col].dtype)}

            # Null percentage drift
            if self.null_drift:
                null1 = df1[col].isnull().mean()
                null2 = df2[col].isnull().mean()
                row["Null %^"] = f"{(null2 - null1) * 100:.1f}%" if not pd.isnull(null1) and not pd.isnull(null2) else "N/A"

            # Duplicate percentage drift
            if self.dup_drift:
                dup1 = df1.duplicated(subset=[col]).mean()
                dup2 = df2.duplicated(subset=[col]).mean()
                row["Dup %^"] = f"{(dup2 - dup1) * 100:.1f}%" if not pd.isnull(dup1) and not pd.isnull(dup2) else "N/A"

            # Mean drift for numeric columns
            if self.mean_drift:
                if pd.api.types.is_numeric_dtype(df1[col]):
                    mean_diff = df2[col].mean() - df1[col].mean()
                    row["Mean ^"] = f"{mean_diff:.2f}" if not pd.isnull(mean_diff) else "N/A"
                else:
                    row["Mean ^"] = "N/A"

            # Category set drift for object or categorical columns
            if self.category_drift:
                if pd.api.types.is_object_dtype(df1[col]) or pd.api.types.is_categorical_dtype(df1[col]):
                    unique1 = set(df1[col].dropna().unique())
                    unique2 = set(df2[col].dropna().unique())
                    drifted_categories = unique1.symmetric_difference(unique2)
                    row["Categories Drifted"] = (
                        ", ".join(map(str, list(drifted_categories))) if drifted_categories else "No Change"
                    )
                else:
                    row["Categories Drifted"] = "N/A"

            # Data type drift
            if self.type_drift:
                row["Type Changed"] = "Yes" if str(df1[col].dtype) != str(df2[col].dtype) else "No"

            # Append row to the report
            report.append(row)

        # Convert report to DataFrame
        final_report = pd.DataFrame(report)

        # Reorder columns based on enabled flags
        if self.verbose:
            columns_order = ["Column Name", "DataType"]
            if self.null_drift: columns_order.append("Null %^")
            if self.dup_drift: columns_order.append("Dup %^")
            if self.mean_drift: columns_order.append("Mean ^")
            if self.category_drift: columns_order.append("Categories Drifted")
            if self.type_drift: columns_order.append("Type Changed")
            final_report = final_report[columns_order]

        # Print the report
        print("\nDrift Summary Report (df1 vs df2)\n")
        print(final_report.to_string(index=False))

        return final_report


