import pandas as pd
from drift_checker import DriftChecker  # assume your file is named drift_checker.py

# DataFrame 1
df1 = pd.DataFrame({
    'name': ['Alice', 'Bob', 'Charlie', 'David', 'Eve', 'Frank', 'Grace', 'Heidi', 'Ivan', 'Judy', 'Karl', 'Leo'],
    'age': [25, 30, 35,25, 30, 35,46,77,54,34,98,34],
    'city': ['New York', 'Paris', 'London', 'Berlin', 'Madrid', 'New York', 'Paris', 'London', 'Berlin', 'Madrid', 'New York', 'Paris']
})

# DataFrame 2 with a null and a duplicate
df2 = pd.DataFrame({
    'name': ['Alice', 'Bob', 'Charlie', 'David', 'Eve', 'Frank', 'Ashutosh', 'Heidi', 'Ashutosh', 'Judy', 'Karl', 'Leo'],
    'age': [25, None, 35,45,67,2,34,77,898,765,4,None],  
    'city': ['New York', 'Paris', 'London', None, 'Madrid', 'New York', 'Paris', 'India', 'Berlin', 'Madrid', 'New York', 'Paris']
})


# Run the check
checker = DriftChecker()
result = checker.check(df1, df2)



