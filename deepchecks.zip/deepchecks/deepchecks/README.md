# DriftChecker 📊

**DriftChecker** is a lightweight and customizable Python utility that allows you to compare two pandas DataFrames and detect various forms of **data drift**. It's useful in scenarios such as monitoring ML pipelines, data versioning, and anomaly detection during ETL or data migration processes.

---

## 🚀 Features

- **Null Percentage Drift**: Compare missing value percentages between datasets.
- **Duplicate Percentage Drift**: Detect changes in duplicate distributions column-wise.
- **Mean Drift**: Measure mean value changes for numerical columns.
- **Category Drift**: Identify differences in categorical values between datasets.
- **Data Type Drift**: Catch changes in column data types across versions.
- **Console Report**: Auto-generates a detailed tabular summary directly in the console.
- **Selective Checks**: Turn on/off each drift type using initialization flags.
- **Error Handling**: Raises an exception if no matching columns are found.

---

## 📦 Installation

Simply place the `drift_checker.py` file in your project directory and import the class:

```bash
pip install pandas 
pip install numpy
